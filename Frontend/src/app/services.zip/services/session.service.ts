import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Domaine } from '../domaine/Domaine';
import { Session } from '../session/session';
import { environment } from 'src/environments/environment';

@Injectable({providedIn: 'root'})
export class SessionService {
    apiBaseUrl: 'http://localhost:8080'
  private apiServerUrl ='http://localhost:9090/session'

  constructor(private http: HttpClient){}

  public getSessions(): Observable<Session[]> {
    return this.http.get<Session[]>(`${this.apiServerUrl}`);
  }

  public addSession(session: Session): Observable<Session> {
    return this.http.post<Session>(`${this.apiServerUrl}`, session);
  }

  public getSessionById(sessionId: number): Observable<Session[]> {
    return this.http.get<Session[]>(`${this.apiServerUrl}/${sessionId}`);
  }

}